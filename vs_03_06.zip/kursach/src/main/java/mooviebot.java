import org.jsoup.nodes.Element;
import org.telegram.telegrambots.bots.TelegramLongPollingBot;
import org.telegram.telegrambots.meta.api.methods.AnswerCallbackQuery;
import org.telegram.telegrambots.meta.api.methods.ParseMode;
import org.telegram.telegrambots.meta.api.methods.send.SendMessage;
import org.telegram.telegrambots.meta.api.methods.send.SendPhoto;
import org.telegram.telegrambots.meta.api.methods.updatingmessages.EditMessageText;
import org.telegram.telegrambots.meta.api.objects.File;
import org.telegram.telegrambots.meta.api.objects.Message;
import org.telegram.telegrambots.meta.api.objects.Update;
import org.telegram.telegrambots.meta.api.objects.replykeyboard.ForceReplyKeyboard;
import org.telegram.telegrambots.meta.api.objects.replykeyboard.InlineKeyboardMarkup;
import org.telegram.telegrambots.meta.api.objects.replykeyboard.ReplyKeyboardMarkup;
import org.telegram.telegrambots.meta.api.objects.replykeyboard.buttons.InlineKeyboardButton;
import org.telegram.telegrambots.meta.api.objects.replykeyboard.buttons.KeyboardRow;
import org.telegram.telegrambots.meta.exceptions.TelegramApiException;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;


public class mooviebot extends TelegramLongPollingBot {


    private static ArrayList<String> new_country;
    private final String botUserName = "VkKusvowBot";
    private final String botToken = "1439301783:AAHuMngYATbvrc4OywKv7nMtRQj2n5kmViA";


    @Override
    public String getBotUsername() {
        return botUserName;
    }

    @Override
    public String getBotToken() {
        return botToken;
    }


    @Override
    public void onUpdateReceived(Update update) {   // как бот будет реагировать на новое сообщение

        if (update.hasMessage()) {
            if (update.getMessage().hasText()) {
                try {
                    //execute(sendMessage(update));
                    execute(search(update.getMessage().getChatId()));
                } catch (TelegramApiException e) {
                    e.printStackTrace();
                }
            }
        }/*else if (update.hasCallbackQuery()) {

            String calls = update.getCallbackQuery().getData();
            long messageId = update.getCallbackQuery().getMessage().getMessageId();
            long chatId = update.getCallbackQuery().getMessage().getChatId();

            if (calls.equals("yep")){

                EditMessageText editMessageText = new EditMessageText();
                editMessageText.setChatId(String.valueOf(chatId));
                editMessageText.setMessageId((int) messageId);
                editMessageText.setText("continue");

                try {
                    execute(editMessageText);
                } catch (TelegramApiException e) {
                    e.printStackTrace();
                }
            }
            else if (calls.equals("nope")){
                EditMessageText editMessageText = new EditMessageText();
                editMessageText.setChatId(String.valueOf(chatId));
                editMessageText.setMessageId((int) messageId);
                editMessageText.setText("watch");

                try {
                    execute(editMessageText);
                } catch (TelegramApiException e) {
                    e.printStackTrace();
                }
            }
        }*/
    }



    public SendMessage sendMessage(Update update) {


        int stage250 = -1;
        if (update.getMessage().getText().equals("/start")) {
            return start(update.getMessage().getChatId());
        }
        if (update.getMessage().getText().equals("/start")) {
            return null;
        }
        /* ВЛОЖЕННЫЕ КЛАВИАТУРЫ
        Пока я нашёл только один вариант - делать не вложенные if .
        Т.к он просто туда не заходит из-за того, что передаваемое сообщение не изменяется внутри функции getMessage()
         */
        SendMessage sendMessage = new SendMessage();
        sendMessage.setText("К сожалению нам не удалось распознать вашу команду");
        sendMessage.setChatId(String.valueOf(update.getMessage().getChatId()));
        return sendMessage;
    }

    private InlineKeyboardMarkup setInline(String msg) //функция для прикрепления мини-опросика к фильму(да/нет/следующий)
    {
        if (msg.equals("Top-film")) {
            InlineKeyboardMarkup inlineKeyboardMarkup = new InlineKeyboardMarkup();  //создаем переменные, куда мы будем записывать наши кнопки к сообщению
            InlineKeyboardButton inlineKeyboardButton = new InlineKeyboardButton();
            InlineKeyboardButton inlineKeyboardButton1 = new InlineKeyboardButton();
            List<InlineKeyboardButton> keyboardButtonsRow1 = new ArrayList<>();
            List<List<InlineKeyboardButton>> rowList = new ArrayList<>();

            inlineKeyboardButton.setText("Да");
            inlineKeyboardButton.setCallbackData("Да");
            inlineKeyboardButton1.setText("Нет, еще что-нибудь");
            inlineKeyboardButton1.setCallbackData("Нет, еще что-нибудь");
            ;
            keyboardButtonsRow1.add(inlineKeyboardButton);
            keyboardButtonsRow1.add(inlineKeyboardButton1);
            rowList.add(keyboardButtonsRow1);
            inlineKeyboardMarkup.setKeyboard(rowList);
            return inlineKeyboardMarkup;
        }
        return null;
    }

    private SendMessage start(long chatId) //основная менюшка для бота(под комманду /start)
    {
        ReplyKeyboardMarkup replyKeyboardMarkup = new ReplyKeyboardMarkup();
        ArrayList<KeyboardRow> keyboard = new ArrayList<>();
        KeyboardRow keyboardRow1 = new KeyboardRow();
        KeyboardRow keyboardRow2 = new KeyboardRow();
        KeyboardRow keyboardRow3 = new KeyboardRow();

        replyKeyboardMarkup.setSelective(true); //показ клав только определенным пользователям
        replyKeyboardMarkup.setOneTimeKeyboard(false);//скрыть клавиатуру после использования
        replyKeyboardMarkup.setResizeKeyboard(true); //высота клавиатуры


        keyboardRow1.clear();
        keyboardRow2.clear();
        keyboard.clear();
        keyboardRow1.add("Поиск");
        keyboardRow1.add("Список фильмов");
        keyboardRow2.add("По жанрам");
        keyboardRow2.add("По интересам");
        keyboardRow3.add("Инструкция");
        keyboard.add(keyboardRow1);
        keyboard.add(keyboardRow2);
        keyboard.add(keyboardRow3);
        replyKeyboardMarkup.setKeyboard(keyboard);

        SendMessage sendMessage = new SendMessage();
        sendMessage.setChatId(String.valueOf(chatId));
        sendMessage.setReplyMarkup(replyKeyboardMarkup);
        sendMessage.setText("Добро пожаловать в наш фильмобот! Выберите, что вы хотите сделать из списка ниже");
        return sendMessage;


    }
    private SendMessage search(long chatId)
    {
        InlineKeyboardMarkup inlineKeyboardMarkup = new InlineKeyboardMarkup();  //создаем переменные, куда мы будем записывать наши кнопки к сообщению
        InlineKeyboardButton inlineKeyboardButton = new InlineKeyboardButton();
        InlineKeyboardButton inlineKeyboardButton1 = new InlineKeyboardButton();
        InlineKeyboardButton inlineKeyboardButton2 = new InlineKeyboardButton();
        InlineKeyboardButton inlineKeyboardButton3 = new InlineKeyboardButton();
        InlineKeyboardButton inlineKeyboardButton4 = new InlineKeyboardButton();

        List<InlineKeyboardButton> keyboardButtonsRow1 = new ArrayList<>();
        List<InlineKeyboardButton> keyboardButtonsRow2 = new ArrayList<>();
        List<InlineKeyboardButton> keyboardButtonsRow3 = new ArrayList<>();
        List<InlineKeyboardButton> keyboardButtonsRow4 = new ArrayList<>();
        List<InlineKeyboardButton> keyboardButtonsRow5 = new ArrayList<>();

        List<List<InlineKeyboardButton>> rowList = new ArrayList<>();

        inlineKeyboardButton.setText("Комедии");
        inlineKeyboardButton.setCallbackData("comedy");
        inlineKeyboardButton1.setText("Драммы");
        inlineKeyboardButton1.setCallbackData("dramma");
        inlineKeyboardButton2.setText("Боевики");
        inlineKeyboardButton2.setCallbackData("action");
        inlineKeyboardButton3.setText("Мелодраммы");
        inlineKeyboardButton3.setCallbackData("romance");
        inlineKeyboardButton4.setText("Мультфильмы");
        inlineKeyboardButton4.setCallbackData("animation");



        keyboardButtonsRow1.add(inlineKeyboardButton);
        keyboardButtonsRow2.add(inlineKeyboardButton1);
        keyboardButtonsRow3.add(inlineKeyboardButton2);
        keyboardButtonsRow4.add(inlineKeyboardButton3);
        keyboardButtonsRow5.add(inlineKeyboardButton4);

        rowList.add(keyboardButtonsRow1);
        rowList.add(keyboardButtonsRow2);
        rowList.add(keyboardButtonsRow3);
        rowList.add(keyboardButtonsRow4);
        rowList.add(keyboardButtonsRow5);


        inlineKeyboardMarkup.setKeyboard(rowList);

        SendMessage send = new SendMessage();
        send.setText("Добро пожаловать в наш фильмобот! Выберите, какие фильмы вы хотите увидеть");
        send.setReplyMarkup(inlineKeyboardMarkup);
        send.setChatId(String.valueOf(chatId));
        return send;
    }
//    private SendMessage answer(Update update) throws TelegramApiException //обработка ответов от кнопок
//    {
//        SendMessage send = new SendMessage();
//        send.setText("Добро пожаловать в наш фильмобот! Выберите, какие фильмы вы хотите увидеть");
//        send.setChatId(String.valueOf(update.getCallbackQuery().getMessage().getChatId()));
//
//        if(update.getCallbackQuery().getData().equals("comedy"))
//
//        return send;
//    }
}



