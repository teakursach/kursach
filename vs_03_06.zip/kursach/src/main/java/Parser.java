import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;

public class Parser {
    public static Document getPage() throws IOException {
        String url = "https://www.kinopoisk.ru/s/";
        Document page = Jsoup.parse(new URL(url), 3000);
        Document doc = Jsoup.connect(url)
                .data("query", "Java")
                .userAgent("Chrome")
                .cookie("auth", "token")
                .timeout(20000)
                .post();
        return page;
    }
    public static void pars() throws IOException {
        ArrayList<String> countryList = new ArrayList<>();
        Document page = getPage();
        // Парсит страны
//        Element country = page.select("select[class=text el_5 __countrySB__]").first();
//        Elements elements = country.select("option[value]");
//        for (Element el : elements) {
//            countryList.add(el.text());
//            //System.out.println(el.text());
//        }
        //Парсит жанры
        Element style = page.select("select[class=text el_6 __genreSB__]").first();
        Elements per_styles = style.select("option[value]");
        for (Element a : per_styles) {
            countryList.add(a.text());
            //System.out.println(a.text());
        }
        //mooviebot.setArray(countryList);
    }
}
