import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;
import org.telegram.telegrambots.meta.api.objects.InputFile;

import java.io.IOException;


public class FilmsTop {
    protected static Document document;  //куда изначально кладется наша страница

    /*public static String getTop(String param, int i) {  //парсер к кнопкам. Параметры i-на каком остановился топ.
                                                      //param - параметр для парсинга Kinopoisk
                                                        //возвращает String с фильмом по указанному методу

            try {
                document = Jsoup.connect("https://www.kinopoisk.ru/lists/"+param).get();

            } catch (IOException e) {
                e.printStackTrace();
            }
        Elements name = document.select("p[class=selection-film-item-meta__name]"); //название
        Elements rating = document.select("span[class=rating__value rating__value_positive]"); //рейтинг
        Elements position = document.select("span[class=film-item-rating-position__position]"); //место, которое занимает фильм в подборке
        Elements country = document.select("span[class=selection-film-item-meta__meta-additional-item]"); //страна
        Elements original_name = document.select("p[class=selection-film-item-meta__original-name]"); //оригинальное название
        Elements zhanr = document.select("span[class=selection-film-item-meta__meta-additional-item]"); //жанр
        return "\n\n\n" + name.get(i).text() + "\n" + "Рейтинг: " + rating.get(i).text() + "\n"
                + "Позиция: " + position.get(i).text()
                + " место" + "\n"
                + "Страна:" + country.get(i).text() + "\n"
                + "Оригинальное название: " + original_name.get(i).text() + "\n"
                + "Жанр: " + country.get(i+1).text();                           // так как в парсере классы для жанра и для страны совпадают, то их надо как то отделить
                                                                                // чтобы убрать этот костыль
    }*/


    public static String getTop(String param) {  //парсер к кнопкам. Параметры i-на каком остановился топ.
        //param - параметр для парсинга Kinopoisk
        //возвращает String с фильмом по указанному методу

        try {
            document = Jsoup.connect("https://www.kinopoisk.ru/lists/"+param).get();

        } catch (IOException e) {
            e.printStackTrace();
        }
        Elements name = document.select("p[class=selection-film-item-meta__name]"); //название
        Elements rating = document.select("span[class=rating__value rating__value_positive]"); //рейтинг
        Elements position = document.select("span[class=film-item-rating-position__position]"); //место, которое занимает фильм в подборке
        Elements country = document.select("span[class=selection-film-item-meta__meta-additional-item]"); //страна
        Elements original_name = document.select("p[class=selection-film-item-meta__original-name]"); //оригинальное название
        Elements zhanr = document.select("span[class=selection-film-item-meta__meta-additional-item]"); //жанр
        return "\n\n\n" + name.text() + "\n" + "Рейтинг: " + rating.text() + "\n"
                + "Позиция: " + position.text()
                + " место" + "\n"
                + "Страна:" + country.text() + "\n"
                + "Оригинальное название: " + original_name.text() + "\n"
                + "Жанр: " + country.text();                           // так как в парсере классы для жанра и для страны совпадают, то их надо как то отделить
        // чтобы убрать этот костыль
    }

    public static String films(int i){  //получаем ссылку на постер/изображение фильма (парсер изображения)

        Elements poster = document.select("img[class=selection-film-item-poster__image]"); //постер
         return poster.get(i).attr("src");

    }




}
