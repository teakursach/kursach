public class kinopoisk {

    private String title;
    private String rated;
    private String year;
    private String country;
    private String poster;
    private String zhanr;
    private String plot;

    public String getTitle() { return title; }
    public void getTitle(String titles) { title = titles; }

    public String getRated() { return rated; }
    public void getRated(String rates) { rated = rates; }

    public String getYear() { return year; }
    public void getYear(String years) { year = years; }

    public String getCountry() { return country; }
    public void getCountry(String countries) { country = countries; }

    public String getPoster() { return poster; }
    public void getPoster(String posters) { poster = posters; }

    public String getZhanr() { return zhanr; }
    public void getZhanr(String zhanrs) { zhanr = zhanrs; }

    public String getPlot() { return plot; }
    public void setPlot(String plots) { plot = plots; }
}
